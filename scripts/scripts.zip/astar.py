import sys
import copy
import math
def myFunction(start, goal, walls, pits, moveList, map_size):
	w, h = map_size[1], map_size[0]
	Matrix = [[0 for x in range(w)] for y in range(h)]
	i = 0
	g_x = goal[0]
	g_y = goal[1]
	start_x = start[0]
	start_y = start[1]
	#cameFrom = copy.deepcopy(Matrix)
	for row in Matrix:
	   j = 0
	   for column in row:
	      Matrix[i][j] = abs(g_x - i) + abs(g_y - j)
	      j += 1
	   i += 1
	
	closedSet = []
	openSet = [start]
	gScore = [[sys.maxsize for x in range(w)] for y in range(h)]
	gScore[start_x][start_y] = 0
	fScore = copy.deepcopy(gScore)
	fScore[start_x][start_y] = Matrix[start_x][start_y]
	cameFrom = [[[0,0] for x in range(w)] for y in range(h)]
	#moveList = [[0,1],[0,-1],[1,0],[-1,0]]
	
	while(len(openSet) != 0):
		current = min_fScore_node(openSet, fScore)
		if current[0] == g_x and current[1] == g_y:
			return reconstruct_path(cameFrom, current, start)
		openSet.remove(current)
		closedSet.append(current)
	
		for elem in moveList:
			elem_x = elem[0]
			elem_y = elem[1]
			neighbor = [elem_x + current[0]]
			neighbor.append(elem_y + current[1])
			if neighbor[0] < 0 or neighbor [1] < 0 or neighbor[0] > h-1 or neighbor[1] > w-1:
				continue
			if neighbor in walls or neighbor in pits:
				continue
			if neighbor in closedSet:
				continue
			tentative_gScore = gScore[current[0]][current[1]] + 1#dist(current, neighbor)
			if neighbor not in openSet:
				openSet.append(neighbor)
			elif tentative_gScore >= gScore[neighbor[0]][neighbor[1]]:
				continue
			cameFrom[neighbor[0]][neighbor[1]] = (current[0], current[1])
			gScore[neighbor[0]][neighbor[1]] = tentative_gScore
			fScore[neighbor[0]][neighbor[1]] = gScore[neighbor[0]][neighbor[1]] + Matrix[neighbor[0]][neighbor[1]]
	return -1

def reconstruct_path(cameFrom, current, start):
	totalPath = [[current[0], current[1]]]
	count = 0
	while (count < 9):
		current = cameFrom[current[0]][current[1]]
		totalPath.append(current)
		if current[0] == start[0] and current[1] == start[1]:
			print(current)
			break
	print(totalPath)
	return totalPath
	
def min_fScore_node(openSet, fScore):
	min = sys.maxsize
	node_x_ret = 0
	node_y_ret = 0
	for node in openSet:
		node_x = node[0]
		node_y = node[1]
		if(fScore[node_x][node_y] < min):
			min = fScore[node_x][node_y]
			node_x_ret = node_x
			node_y_ret = node_y
	return [node_x_ret, node_y_ret]
#def dist(current, neighbor):
#	return math.sqrt(math.pow((current[0]-neighbor[0]), 2) + math.pow((current[1] - neighbor[1]), 2))
#print(myFunction([2, 0], [0, 3], [2,1]))
			
