#!/usr/bin/env python

import rospy
import random
import math as m
import numpy as np
from copy import deepcopy
from cse_190_assi_3.msg import AStarPath
from cse_190_assi_3.msg import PolicyList
import astar
from std_msgs.msg import Bool
from std_msgs.msg import String
from std_msgs.msg import Float32
from read_config import read_config


class Robot():

    def __init__(self):
        """Read config file and setup ROS things"""
        self.config = read_config()
        rospy.init_node("robot")
        self.astar_pub = rospy.Publisher("/results/path_list", AStarPath, queue_size=10)
        self.mdp_pub = rospy.Publisher("/results/policy_list", PolicyList, queue_size=10)
        self.complete_mess = rospy.Publisher("/map_node/sim_complete", Bool, queue_size=10)
        self.mlist = self.config['move_list']
        self.map_size = self.config['map_size'] 
        self.walls = self.config['walls'] 
        self.pits = self.config['pits'] 
        self.start = self.config['start'] 
        self.goal = self.config['goal'] 
        mdp_res = ['N']*(self.map_size[0]*self.map_size[1])
        a_path = astar.myFunction(self.start, self.goal, self.walls, self.pits, self.mlist, self.map_size)
        a_path.reverse()
        for x in a_path:
          rospy.sleep(1)
          self.astar_pub.publish(x)
        for x in mdp_res:
          rospy.sleep(1)
          self.mdp_pub.publish(x)
        rospy.sleep(1)
        self.complete_mess.publish(True)
        rospy.sleep(2)
        rospy.signal_shutdown("Done.") 
    
if __name__ == '__main__':
    r = Robot()
